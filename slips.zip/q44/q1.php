<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $name = htmlspecialchars($_POST['name']);
    $salary = htmlspecialchars($_POST['salary']);
    $designation = htmlspecialchars($_POST['designation']);
    $address = htmlspecialchars($_POST['address']);

   
    echo "<h1>Employee Details</h1>";
    echo "<p>Name: " . $name . "</p>";
    echo "<p>Salary: " . $salary . "</p>";
    echo "<p>Designation: " . $designation . "</p>";
    echo "<p>Address: " . $address . "</p>";
} else {
   
   
}
?>
