<!DOCTYPE html>
<html>
<head>
    <title>Grade Calculator</title>
</head>
<body>
    <input type="number" id="subject1" placeholder="Subject 1 Marks"><br>
    <input type="number" id="subject2" placeholder="Subject 2 Marks"><br>
    <input type="number" id="subject3" placeholder="Subject 3 Marks"><br>
    <input type="number" id="subject4" placeholder="Subject 4 Marks"><br>
    <input type="number" id="subject5" placeholder="Subject 5 Marks"><br>
    <button onclick="calculateResults()">Calculate</button>
    <p id="result"></p>

    <script>
        function calculateResults() {
            var marks = [];
            var sum = 0;
            for (var i = 1; i <= 5; i++) {
                marks.push(document.getElementById('subject' + i).value);
                sum += parseInt(marks[i-1]);
            }
            var percentage = sum / 5;
            document.getElementById('result').innerHTML = "Total: " + sum + ", Percentage: " + percentage + "%";
        }
    </script>
</body>
</html>
