<!DOCTYPE html>
<html>
<head>
 <title>Calculate Percentage</title>
</head>
<body>
 <h2>Calculate Percentage</h2>
 <label>Enter marks for Subject 1:</label>
 <input type="number" id="subject1">
 <br>
 <label>Enter marks for Subject 2:</label>
 <input type="number" id="subject2">
 <br>
 <label>Enter marks for Subject 3:</label>
 <input type="number" id="subject3">
 <br>
 <label>Enter marks for Subject 4:</label>
 <input type="number" id="subject4">
 <br>
 <label>Enter marks for Subject 5:</label>
 <input type="number" id="subject5">
 <br>
 <button onclick="calculate()">Calculate</button>
 <p id="result"></p>
 <script>
 function calculate() {
 var subject1 = parseFloat(document.getElementById("subject1").value);
 var subject2 = parseFloat(document.getElementById("subject2").value);
 var subject3 = parseFloat(document.getElementById("subject3").value);
 var subject4 = parseFloat(document.getElementById("subject4").value);
 var subject5 = parseFloat(document.getElementById("subject5").value);
 var totalMarks = subject1 + subject2 + subject3 + subject4 + subject5;
 var percentage = (totalMarks / 500) * 100;
 document.getElementById("result").innerHTML = "Total Marks: " + totalMarks +
"<br>Percentage: " + percentage + "%";
 }
 </script>
</body>
</html>