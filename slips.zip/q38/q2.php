<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shape Area Calculator</title>
</head>
<body>
    <h1>Calculate Area of a Shape</h1>
    <form method="post">
        <p>Select a shape to calculate the area:</p>
        <input type="radio" id="triangle" name="shape" value="triangle" required>
        <label for="triangle">Triangle</label><br>
        <input type="radio" id="square" name="shape" value="square">
        <label for="square">Square</label><br>
        <input type="radio" id="rectangle" name="shape" value="rectangle">
        <label for="rectangle">Rectangle</label><br>
        <input type="radio" id="circle" name="shape" value="circle">
        <label for="circle">Circle</label><br>
        <label for="dimension1">Dimension 1:</label>
        <input type="number" id="dimension1" name="dimension1" placeholder="e.g., width or radius" required><br>
        <label for="dimension2">Dimension 2 (if needed):</label>
        <input type="number" id="dimension2" name="dimension2" placeholder="e.g., height (optional)"><br>
        <button type="submit" name="calculate">Calculate Area</button>
    </form>

    <?php
    class Shape {
        protected function area() {
            return 0;
        }
    }

    class Triangle extends Shape {
        private $base;
        private $height;

        public function __construct($base, $height) {
            $this->base = $base;
            $this->height = $height;
        }

        public function area() {
            return 0.5 * $this->base * $this->height;
        }
    }

    class Square extends Shape {
        private $side;

        public function __construct($side) {
            $this->side = $side;
        }

        public function area() {
            return $this->side * $this->side;
        }
    }

    class Rectangle extends Shape {
        private $width;
        private $height;

        public function __construct($width, $height) {
            $this->width = $width;
            $this->height = $height;
        }

        public function area() {
            return $this->width * $this->height;
        }
    }

    class Circle extends Shape {
        private $radius;

        public function __construct($radius) {
            $this->radius = $radius;
        }

        public function area() {
            return pi() * $this->radius * $this->radius;
        }
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['calculate'])) {
        $shape = $_POST['shape'];
        $dimension1 = $_POST['dimension1'];
        $dimension2 = $_POST['dimension2'] ?? null;

        switch ($shape) {
            case 'triangle':
                $shapeInstance = new Triangle($dimension1, $dimension2);
                break;
            case 'square':
                $shapeInstance = new Square($dimension1);
                break;
            case 'rectangle':
                $shapeInstance = new Rectangle($dimension1, $dimension2);
                break;
            case 'circle':
                $shapeInstance = new Circle($dimension1);
                break;
            default:
                $shapeInstance = null;
        }

        if ($shapeInstance) {
            echo "<p>The area of the {$shape} is: " . $shapeInstance->area() . " square units.</p>";
        }
    }
    ?>
</body>
</html>
