<!DOCTYPE html>
<html>
<head>
 <style>
 span {
 font-size: 25px;
 }
 table {
 color: crimson;
 border-collapse: collapse;
 }
 </style>
 <script type="text/javascript">
 function displayContacts() {
 var xhr = new XMLHttpRequest();
 xhr.open("GET", "P5.php");
 xhr.send();
 xhr.onreadystatechange = function () {
 if (xhr.readyState == 4 && xhr.status == 200) {
 document.getElementById("contactTable").innerHTML = xhr.responseText;
 }
 }
 }
 </script>
</head>
<body>
 <center>
 <h3>Display the contents of a contact.dat file</h3>
 <br><input type="button" value="Display Contacts" onclick="displayContacts()">
 <div id="contactTable"></div>
 </center>
</body>
</html>