<?php
session_start();
$correct_username = "admin";
$correct_password = "password";
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
 $username = $_POST["username"];
 $password = $_POST["password"];
 // Check if username and password are correct
 if ($username === $correct_username && $password === $correct_password) {
 // Set session variable to indicate successful login
 $_SESSION["logged_in"] = true;
 $_SESSION["username"] = $username;
 // Redirect to second form
 header("Location: php2.php");
 exit();
 } else {
 // Increment login attempts
 if (!isset($_SESSION["login_attempts"])) {
 $_SESSION["login_attempts"] = 1;
 } else {
 $_SESSION["login_attempts"]++;
 }
 }
}
// Check if maximum login attempts reached
$max_attempts = 3;
if (isset($_SESSION["login_attempts"]) && $_SESSION["login_attempts"] >= $max_attempts) {
 echo "Maximum login attempts reached. Please try again later.";
 session_destroy();
 exit();
}
// Calculate remaining attempts
$remaining_attempts = $max_attempts - $_SESSION["login_attempts"];
?>
<!DOCTYPE html>
<html>
<head>
 <title>Login Form</title>
</head>
<body>
 <h2>Login</h2>
 <p><?php echo "You have $remaining_attempts attempts remaining."; ?></p>
 <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
 <label for="username">Username:</label><br>
 <input type="text" id="username" name="username"><br>
 <label for="password">Password:</label><br>
 <input type="password" id="password" name="password"><br><br>
 <input type="submit" value="Login">
 </form>
</body>
</html>