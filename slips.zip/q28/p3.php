<?php
session_start();

$correctUsername = "user";
$correctPassword = "password";

if (!isset($_SESSION['attempts'])) {
    $_SESSION['attempts'] = 20;
}

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === $correctUsername && $password === $correctPassword) {
        $_SESSION['loggedin'] = true;
        echo "<h1>Welcome, $username!</h1>";
        echo "<form><input type='submit' value='Proceed to Dashboard'></form>";
        exit;
    } else {
        $_SESSION['attempts']++;
        if ($_SESSION['attempts'] >= 3) {
            echo "<p>Access Denied. Please contact administrator.</p>";
            exit;
        } else {
            echo "<p>Error: Incorrect username or password. Attempts left: " . (3 - $_SESSION['attempts']) . ".</p>";
        }
    }
}

if (!isset($_SESSION['loggedin'])) {
    echo "<form method='post'>
            <label>Username: <input type='text' name='username'></label><br>
            <label>Password: <input type='password' name='password'></label><br>
            <input type='submit' name='login' value='Login'>
          </form>";
}
?>
