<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dynamic Array Operations</title>
</head>
<body>
    <h1>Dynamic Array Operations</h1>
    <form method="post">
        <label for="key">Key:</label>
        <input type="text" id="key" name="key" placeholder="Enter key">
        <label for="value">Value:</label>
        <input type="text" id="value" name="value" placeholder="Enter value">
        <button type="submit" name="add">Add to Array</button>
    </form>

    <form method="post">
        <button type="submit" name="display">Display Array</button>
        <button type="submit" name="size">Display Size of Array</button>
    </form>

    <?php
    session_start();

    if (!isset($_SESSION['array'])) {
        $_SESSION['array'] = [];
    }

    if (isset($_POST['add'])) {
        $key = $_POST['key'];
        $value = $_POST['value'];
        if ($key != '' && $value != '') {
            $_SESSION['array'][$key] = $value;
        }
    }

    if (isset($_POST['display'])) {
        echo "<h2>Array Elements:</h2>";
        foreach ($_SESSION['array'] as $key => $value) {
            echo "$key => $value<br>";
        }
    }

    if (isset($_POST['size'])) {
        echo "<h2>Size of the Array:</h2>";
        echo count($_SESSION['array']);
    }
    ?>
</body>
</html>
