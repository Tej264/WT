<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Details - Step 1</title>
</head>
<body>
    <h1>Enter Employee Details</h1>
    <form action="step2.php" method="post">
        <label>Employee Number: <input type="text" name="eno"></label><br>
        <label>Employee Name: <input type="text" name="ename"></label><br>
        <label>Address: <input type="text" name="address"></label><br>
        <button type="submit">Next</button>
    </form>
</body>
</html>
