<?php
session_start();

if (!empty($_POST['basic']) && !empty($_POST['da']) && !empty($_POST['hra'])) {
    $_SESSION['basic'] = $_POST['basic'];
    $_SESSION['da'] = $_POST['da'];
    $_SESSION['hra'] = $_POST['hra'];
    // Calculate total
    $_SESSION['total'] = $_SESSION['basic'] + $_SESSION['da'] + $_SESSION['hra'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Information - Final Details</title>
</head>
<body>
    <h1>Employee Information</h1>
    <p>Employee Number: <?php echo $_SESSION['eno']; ?></p>
    <p>Employee Name: <?php echo $_SESSION['ename']; ?></p>
    <p>Address: <?php echo $_SESSION['address']; ?></p>
    <p>Basic Salary: <?php echo $_SESSION['basic']; ?></p>
    <p>DA: <?php echo $_SESSION['da']; ?></p>
    <p>HRA: <?php echo $_SESSION['hra']; ?></p>
    <p>Total Earnings: <?php echo $_SESSION['total']; ?></p>
</body>
</html>
