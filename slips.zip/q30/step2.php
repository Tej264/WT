<?php
session_start();

if (!empty($_POST['eno']) && !empty($_POST['ename']) && !empty($_POST['address'])) {
    $_SESSION['eno'] = $_POST['eno'];
    $_SESSION['ename'] = $_POST['ename'];
    $_SESSION['address'] = $_POST['address'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Earnings - Step 2</title>
</head>
<body>
    <h1>Enter Employee Earnings</h1>
    <form action="step3.php" method="post">
        <label>Basic Salary: <input type="number" name="basic"></label><br>
        <label>DA (Dearness Allowance): <input type="number" name="da"></label><br>
        <label>HRA (Housing Rent Allowance): <input type="number" name="hra"></label><br>
        <button type="submit">Next</button>
    </form>
</body>
</html>
