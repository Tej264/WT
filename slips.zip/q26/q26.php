<!DOCTYPE html>
<html>
<head>
    <title>Vowel Counter</title>
</head>
<body>
    <form method="post">
        Enter a string: <input type="text" name="string">
        <input type="submit" value="Count Vowels">
    </form>
    <?php
    function countVowels($str) {
        $vowelsCount = ['a' => 0, 'e' => 0, 'i' => 0, 'o' => 0, 'u' => 0];
        $str = strtolower($str);
        for ($i = 0; $i < strlen($str); $i++) {
            if (isset($vowelsCount[$str[$i]])) {
                $vowelsCount[$str[$i]]++;
            }
        }
        return $vowelsCount;
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $string = $_POST['string'];
        $vowels = countVowels($string);
        echo "Total vowels: " . array_sum($vowels) . "<br>";
        echo "Occurrences: <br>";
        foreach ($vowels as $vowel => $count) {
            echo strtoupper($vowel) . ": " . $count . "<br>";
        }
    }
    ?>
</body>
</html>
