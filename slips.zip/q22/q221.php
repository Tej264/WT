<?php
if(isset($_GET['txtTitle']) && isset($_GET['publ'])) {
 $ele = $_GET['txtTitle'];
 $att = $_GET['publ'];

 $xmltags = "<?xml version='1.0' encoding='ISO-8859-1'?>";
 $xmltags .= "<BookStore>";
 $xmltags .= "<Books>";
 $xmltags .= "<PHP>";
 $xmltags .= "<Title>" . $ele . "</Title>";
 $xmltags .= "<Publication>" . $att . "</Publication>";
 $xmltags .= "</PHP>";
 $xmltags .= "</Books>";
 $xmltags .= "</BookStore>";
 if($fp = fopen("books.xml", "w")) {
 if($wt = fwrite($fp, $xmltags)) {
 echo "File created";
 } else {
 echo "Failed to write to file";
 }
 fclose($fp);
 } else {
 echo "Failed to open file";
 }
}
?>