<?php
$xml = new SimpleXMLElement('<Book_Store/>');

$books = $xml->addChild('Books');
$php = $books->addChild('PHP');
$php->addChild('Title', 'Programming in PHP');
$php->addChild('Publication', 'O’REILLY');

$php = $books->addChild('PHP');
$php->addChild('Title', 'Beginners PHP');
$php->addChild('Publication', 'WORX');

Header('Content-type: text/xml');
echo $xml->asXML();
?>



