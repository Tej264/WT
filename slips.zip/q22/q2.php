<?php

$doc = new DOMDocument();


$doc->xmlStandalone = true;
$doc->encoding = 'ISO-8859-1';

$doc->formatOutput = true;

$bookStore = $doc->createElement("BookStore");
$doc->appendChild($bookStore);

$books = $doc->createElement("Books");
$bookStore->appendChild($books);

$php1 = $doc->createElement("PHP");
$books->appendChild($php1);

$title1 = $doc->createElement("Title", "Programming in PHP");
$php1->appendChild($title1);

$publication1 = $doc->createElement("Publication", "ORELLY");
$php1->appendChild($publication1);

$php2 = $doc->createElement("PHP");
$books->appendChild($php2);

$title2 = $doc->createElement("Title", "Beginners PHP");
$php2->appendChild($title2);

$publication2 = $doc->createElement("Publication", "WORX");
$php2->appendChild($publication2);

$xmlString = $doc->saveXML();
file_put_contents('BookStore.xml', $xmlString);

echo "XML file 'BookStore.xml' has been created successfully.";
?>
