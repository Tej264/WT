<?php
$host = "localhost";
$port = "5432";
$dbname = "postgres";
$user = "postgres";
$password = "root";


$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");


if (!$conn) {
    die("Connection failed: " . pg_last_error());
}


if(isset($_POST['c_no'])) {
    $c_no = $_POST['c_no'];
    $query = "SELECT s.stud_id, s.name, s.class FROM Student s 
              JOIN Participation p ON s.stud_id = p.stud_id 
              WHERE p.c_no = $1 AND p.rank = 1";
    $stmt = pg_prepare($conn, "find_top_student", $query);
    $result = pg_execute($conn, "find_top_student", array($c_no));

    if (pg_num_rows($result) > 0) {
        echo "<table border='1'><tr><th>Student ID</th><th>Name</th><th>Class</th></tr>";
        while ($row = pg_fetch_assoc($result)) {
            echo "<tr><td>".$row['stud_id']."</td><td>".$row['name']."</td><td>".$row['class']."</td></tr>";
        }
        echo "</table>";
    } else {
        echo "No results found.";
    }
}

pg_close($conn);
?>

<html>
<body>
    <form method="post">
        Competition Number: <input type="number" name="c_no" required><br>
        <input type="submit" value="Find Top Student">
    </form>
</body>
</html>
