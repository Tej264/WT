<!DOCTYPE html>
<html>
<head>
    <title>Associative Array Advanced Operations</title>
</head>
<body>
    <button onclick="mergeArrays()">Merge Arrays</button>
    <button onclick="findIntersection()">Intersection</button>
    <button onclick="findUnion()">Union</button>
    <button onclick="findDifference()">Set Difference</button>
    <div id="result"></div>

    <script>
        const array1 = {'a': 1, 'b': 2, 'c': 3};
        const array2 = {'b': 2, 'c': 4, 'd': 5};

        function mergeArrays() {
            const merged = {...array1, ...array2};
            document.getElementById('result').innerHTML = JSON.stringify(merged);
        }

        function findIntersection() {
            let intersection = {};
            for (let key in array1) {
                if (array2[key] && array1[key] === array2[key]) {
                    intersection[key] = array1[key];
                }
            }
            document.getElementById('result').innerHTML = JSON.stringify(intersection);
        }

        function findUnion() {
            let union = {...array1, ...array2};
            document.getElementById('result').innerHTML = JSON.stringify(union);
        }

        function findDifference() {
            let difference = {};
            for (let key in array1) {
                if (!array2[key]) {
                    difference[key] = array1[key];
                }
            }
            document.getElementById('result').innerHTML = JSON.stringify(difference);
        }
    </script>
</body>
</html>
