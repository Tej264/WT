<html>
<body>
<form method="post" action="P10.php">
<input type='radio' name='op' value='5'>Merge the given array.<br>
<input type='radio' name='op' value='6'>Find the intersection of two array.<br>
<input type='radio' name='op' value='7'>Find the union of two array.<br>
<input type='radio' name='op' value='8'>Find set differnce of two arrays.<br>
<input type='submit' name='submit' value='submit'>
</form>
</body>
</html>
<?php
$c=$_POST['op'];
$a=array('pen'=>15,'pencil'=>5,'rubber'=>3,'book'=>30);
$a1=array('pen'=>15,'ritika'=>57,'ram'=>3,'revati'=>30);
$a2=array(15,48,10,155,2,78);
function isodd($v) {
if($v%2!=0)
return $v;
}
switch($c)
{
case 5:
print_r($a);
echo "<br>";
print_r($a1);
echo "<br>Array Merge<br>";
print_r(array_merge($a,$a1));
break;
case 6:
print_r($a);
echo "<br>";
print_r($a1);
echo "<br>Array Intersection<br>";
print_r(array_intersect($a,$a1));
break;
case 7:
print_r($a);
echo "<br>";
print_r($a1);
echo "<br>Array Union<br>";
$union=array_merge($a,$a1);
print_r(array_unique($union));
break;
case 8:
print_r($a);
echo "<br>";
print_r($a1);
echo "<br>Array Differnce<br>";
print_r(array_diff($a,$a1));
break;
}
?>