<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Associative Array Operations</title>
</head>
<body>
    <h1>Associative Array Operations</h1>
    <form action="" method="post">
        <h2>Array 1 (key:value, separate by commas)</h2>
        <textarea name="array1" rows="4" cols="50" placeholder="Example: a:1, b:2, c:3"></textarea>
        <h2>Array 2 (key:value, separate by commas)</h2>
        <textarea name="array2" rows="4" cols="50" placeholder="Example: b:2, c:4, d:5"></textarea>
        <br>
        <button type="submit" name="merge">Merge Arrays</button>
        <button type="submit" name="intersect">Find Intersection</button>
        <button type="submit" name="union">Find Union</button>
        <button type="submit" name="difference">Find Set Difference (Array 1 - Array 2)</button>
    </form>

    <?php
    function parseArray($input) {
        $items = explode(',', $input);
        $array = [];
        foreach ($items as $item) {
            $keyValue = explode(':', $item);
            if (count($keyValue) == 2) {
                $array[trim($keyValue[0])] = trim($keyValue[1]);
            }
        }
        return $array;
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $array1 = isset($_POST['array1']) ? parseArray($_POST['array1']) : [];
        $array2 = isset($_POST['array2']) ? parseArray($_POST['array2']) : [];

        if (isset($_POST['merge'])) {
            $result = array_merge($array1, $array2);
            echo "<h2>Merged Array:</h2><pre>" . print_r($result, true) . "</pre>";
        }

        if (isset($_POST['intersect'])) {
            $result = array_intersect($array1, $array2);
            echo "<h2>Intersection of Arrays:</h2><pre>" . print_r($result, true) . "</pre>";
        }

        if (isset($_POST['union'])) {
            $result = $array1 + $array2; // Union of arrays
            echo "<h2>Union of Arrays:</h2><pre>" . print_r($result, true) . "</pre>";
        }

        if (isset($_POST['difference'])) {
            $result = array_diff($array1, $array2);
            echo "<h2>Set Difference (Array 1 - Array 2):</h2><pre>" . print_r($result, true) . "</pre>";
        }
    }
    ?>
</body>
</html>
