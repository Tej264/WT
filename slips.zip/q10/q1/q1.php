<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clg";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST['hname'])) {
    $hname = $_POST['hname'];

    
    $sql = "SELECT d.doc_no, d.dname, d.address, d.city, d.area FROM Doctor d JOIN Hospital h ON d.hosp_no = h.hosp_no WHERE h.hname = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $hname);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<table border='1'><tr><th>Doctor Number</th><th>Name</th><th>Address</th><th>City</th><th>Area</th></tr>";
        while($row = $result->fetch_assoc()) {
            echo "<tr><td>".$row["doc_no"]."</td><td>".$row["dname"]."</td><td>".$row["address"]."</td><td>".$row["city"]."</td><td>".$row["area"]."</td></tr>";
        }
        echo "</table>";
    } else {
        echo "No doctors found for this hospital.";
    }
}
$conn->close();
?>

<html>
<body>
    <form method="post">
        Hospital Name: <input type="text" name="hname"><br>
        <input type="submit" value="Search Doctors">
    </form>
</body>
</html>
