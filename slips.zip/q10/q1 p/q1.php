<?php
$host = "localhost";
$port = "5432";
$dbname = "postgres";
$user = "postgres";
$password = "root";


$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");


if (!$conn) {
    die("Connection failed: " . pg_last_error());
}

if(isset($_POST['hname'])) {
    $hname = $_POST['hname'];

    $query = "SELECT d.doc_no, d.dname, d.address, d.city, d.area FROM Doctor d JOIN Hospital h ON d.hosp_no = h.hosp_no WHERE h.hname = $1";
    $result = pg_prepare($conn, "my_query", $query);
    $result = pg_execute($conn, "my_query", array($hname));

    if (pg_num_rows($result) > 0) {
        echo "<table border='1'><tr><th>Doctor Number</th><th>Name</th><th>Address</th><th>City</th><th>Area</th></tr>";
        while ($row = pg_fetch_assoc($result)) {
            echo "<tr><td>".$row["doc_no"]."</td><td>".$row["dname"]."</td><td>".$row["address"]."</td><td>".$row["city"]."</td><td>".$row["area"]."</td></tr>";
        }
        echo "</table>";
    } else {
        echo "No doctors found for this hospital.";
    }
}

pg_close($conn);
?>

<html>
<body>
    <form method="post">
        Hospital Name: <input type="text" name="hname"><br>
        <input type="submit" value="Search Doctors">
    </form>
</body>
</html>
