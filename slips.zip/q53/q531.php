<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Perfect and Prime Numbers</title>
<script>
function isPrime(num) {
    if (num <= 1) return false;
    for (let i = 2; i * i <= num; i++) {
        if (num % i === 0) return false;
    }
    return true;
}

function isPerfect(num) {
    let sum = 0;
    for (let i = 1; i <= num / 2; i++) {
        if (num % i === 0) {
            sum += i;
        }
    }
    return sum === num;
}

async function printNumbers(n) {
    let primeCount = 0;
    let perfectCount = 0;
    let number = 2;
    const primeResults = [];
    const perfectResults = [];

    function updateResults() {
        document.getElementById('primeResults').innerText = 'Prime Numbers: ' + primeResults.join(', ');
        document.getElementById('perfectResults').innerText = 'Perfect Numbers: ' + perfectResults.join(', ');
    }

    while (primeCount < n || perfectCount < n) {
        if (primeCount < n && isPrime(number)) {
            primeResults.push(number);
            primeCount++;
        }
        if (perfectCount < n && isPerfect(number)) {
            perfectResults.push(number);
            perfectCount++;
        }
        number++;
        if (number % 100 === 0) {
            updateResults();
            await new Promise(resolve => setTimeout(resolve, 1)); // Yield to the browser's event loop
        }
    }

    updateResults(); 
    
}

</script>
</head>
<body>
<h1>Find Prime and Perfect Numbers</h1>
<label for="numberInput">Enter number of elements:</label>
<input type="number" id="numberInput" value="3">
<button onclick="printNumbers(document.getElementById('numberInput').value)">Generate Numbers</button>
<p id="primeResults"></p>
<p id="perfectResults"></p>
</body>
</html>
