<?php
session_start();
if (!isset($_SESSION['page_count'])) {
    $_SESSION['page_count'] = 0;
}
$_SESSION['page_count'] += 1;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Page Access Tracker</title>
</head>
<body>
    <h1>Page has been accessed <?php echo $_SESSION['page_count']; ?> times in this session.</h1>
</body>
</html>
